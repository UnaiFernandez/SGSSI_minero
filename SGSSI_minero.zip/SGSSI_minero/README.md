# SGSSI minero
