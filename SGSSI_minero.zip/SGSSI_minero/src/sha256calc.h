int sha256_file(char *path, char outputBuffef[65]);
void sha256_hash_string (char hash[SHA256_DIGEST_LENGTH], char outputBuffer[65]);
